package com.example.practiceapplication.Model

data class CreateProductRequest(
    val title: String,
    val price: Long,
    val description: String,
    val category: Category,
    val images: List<String>
)
