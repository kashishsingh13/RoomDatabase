package com.example.practiceapplication.Dao

import androidx.room.Dao
import androidx.room.Delete
import androidx.room.Insert
import androidx.room.Query
import androidx.room.Update
import com.example.practiceapplication.Model.Item


@Dao
interface UserDao {

    @Insert
    fun insetUser(user:Item)

    @Query("select * from user_details")
    fun getAllUser(): MutableList<Item>

    @Update
    fun updateUser(user:Item)

    @Delete
    fun deleteUser(user: Item)
}