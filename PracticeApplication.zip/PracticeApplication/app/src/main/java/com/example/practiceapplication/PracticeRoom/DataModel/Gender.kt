package com.example.practiceapplication.PracticeRoom.DataModel

data class Gender(
    var gender:String
) {
    override fun toString(): String {
        return gender
    }
}
