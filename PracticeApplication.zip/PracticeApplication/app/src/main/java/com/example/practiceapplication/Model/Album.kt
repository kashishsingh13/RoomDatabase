package com.example.practiceapplication.Model

data class Album(
    var id :Int,
    var title  :String,
    var cover:String,
    var cover_small:String,
    var type:String

)
