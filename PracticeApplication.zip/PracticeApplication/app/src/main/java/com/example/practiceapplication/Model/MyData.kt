package com.example.practiceapplication.Model

data class  MyData(
val `data`: MutableList<MusicResPonse>,
val next: String,
val total: Int

)
