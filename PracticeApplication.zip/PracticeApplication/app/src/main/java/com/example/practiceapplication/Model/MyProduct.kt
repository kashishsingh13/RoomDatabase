package com.example.practiceapplication.Model

data class MyProduct(
    val productslist :MutableList<Products>
)
