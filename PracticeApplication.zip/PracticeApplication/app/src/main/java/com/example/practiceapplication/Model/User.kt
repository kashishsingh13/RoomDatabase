package com.example.practiceapplication.Model

data class User(
    var name :String,
    var Age:Int,
    var Salary:Double
)
