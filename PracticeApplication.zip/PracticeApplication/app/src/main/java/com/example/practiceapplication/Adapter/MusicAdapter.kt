package com.example.practiceapplication.Adapter

import android.content.Context
import android.media.MediaPlayer
import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.core.net.toUri
import androidx.recyclerview.widget.RecyclerView
import androidx.recyclerview.widget.RecyclerView.ViewHolder
import com.bumptech.glide.request.transition.Transition.ViewAdapter
import com.example.practiceapplication.Model.Music
import com.example.practiceapplication.Model.MusicResPonse
import com.example.practiceapplication.databinding.MusicItemBinding
import com.squareup.picasso.Picasso

class MusicAdapter(var context: Context, var musicList: MutableList<MusicResPonse>):
    RecyclerView.Adapter<MusicAdapter.MyViewHolder>() {
    private var lastSelection: MediaPlayer?=null
    class MyViewHolder(var bind:MusicItemBinding):ViewHolder(bind.root) {


    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): MyViewHolder {
        var binding = MusicItemBinding.inflate(LayoutInflater.from(context), parent, false)
        return MyViewHolder(binding)
    }

    override fun getItemCount(): Int {
        return musicList.size
    }

    override fun onBindViewHolder(holder: MyViewHolder, position: Int) {
        val currentUser = musicList[position]
        var mediaPlayer = MediaPlayer.create(context,currentUser.preview.toUri())

        // Set data to the views in your layout using the data from the User object
        holder.bind.musicid.text = "Id: ${currentUser.artist.id}"
        holder.bind.radio.text = "Email: ${currentUser.album.title}"
        holder.bind.artistname.text = "First Name: ${currentUser.artist.name}"
        holder.bind.type.text = "Last Name: ${currentUser.artist.type}"
        Picasso.get().load(currentUser.artist.picture).into(holder.bind.image)
        Picasso.get().load(currentUser.artist.picture_big).into(holder.bind.image1)

        holder.bind.btnPlay.setOnClickListener {
            if(lastSelection!=null && lastSelection!!.isPlaying){
                lastSelection!!.stop()
            }
            lastSelection = mediaPlayer
            mediaPlayer.start()
        }

        holder.bind.btnPause.setOnClickListener {
            mediaPlayer.pause()
        }
    }
}


