package com.example.practiceapplication.Adapter

import android.content.Context
import android.media.MediaPlayer
import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.core.net.toUri
import androidx.recyclerview.widget.RecyclerView
import com.example.practiceapplication.Model.MusicResPonse
import com.example.practiceapplication.Model.Products
import com.example.practiceapplication.databinding.MusicItemBinding
import com.example.practiceapplication.databinding.ProductItemBinding
import com.squareup.picasso.Picasso

class ProdoctAdapter(var context: Context, var productList:MutableList<Products>):
    RecyclerView.Adapter<ProdoctAdapter.MyViewHolder>() {
    class MyViewHolder(var bind: ProductItemBinding): RecyclerView.ViewHolder(bind.root) {


    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): MyViewHolder {
        var binding = ProductItemBinding.inflate(LayoutInflater.from(context), parent, false)
        return MyViewHolder(binding)
    }

    override fun getItemCount(): Int {
        return productList.size
    }

    override fun onBindViewHolder(holder: MyViewHolder, position: Int) {
        val currentproduct = productList[position]

        // Set data to the views in your layout using the data from the User object
        holder.bind.proid.text = "Id: ${currentproduct.id}"
        holder.bind.title.text = "Email: ${currentproduct.title}"
        holder.bind.price.text = "First Name: ${currentproduct.price}"
        holder.bind.des.text = "Last Name: ${currentproduct.description}"
        holder.bind.catid.text="Id:${currentproduct.category.id}"
        holder.bind.catname.text="Id:${currentproduct.category.name}"
        Picasso.get().load(currentproduct.category.image).into(holder.bind.catimage)
        Picasso.get().load(currentproduct.images.image).into(holder.bind.image)

    }

    fun getProducts(mutableList: MutableList<Products>){
        this.productList = mutableList
        notifyDataSetChanged()
    }
}
