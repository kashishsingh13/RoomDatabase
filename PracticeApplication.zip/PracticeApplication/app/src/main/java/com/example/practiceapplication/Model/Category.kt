package com.example.practiceapplication.Model

data class Category(
    var id :Int,
    var name:String,
    var image:String
)
