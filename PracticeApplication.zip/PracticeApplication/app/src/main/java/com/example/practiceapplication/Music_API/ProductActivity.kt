package com.example.practiceapplication.Music_API

import android.os.Bundle
import android.util.Log
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import com.example.practiceapplication.Adapter.ProdoctAdapter
import com.example.practiceapplication.Model.Products
import com.example.practiceapplication.Network.ApiProduct
import com.example.practiceapplication.databinding.ActivityProductBinding
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response

class ProductActivity : AppCompatActivity() {
    private lateinit var binding:ActivityProductBinding
    private lateinit var productadapter: ProdoctAdapter
    private var productlist= mutableListOf<Products>()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding=ActivityProductBinding.inflate(layoutInflater)
        setContentView(binding.root)

        productadapter = ProdoctAdapter(this, productlist) // You can pass an empty list initially
        binding.recyleview.adapter =productadapter
        binding.recyleview.layoutManager = LinearLayoutManager(this)

        fetchUserList()
    }

    private fun fetchUserList() {

       ApiProduct.init().getproduct().enqueue(object : Callback<List<Products>>{
           override fun onResponse(call: Call<List<Products>>, response: Response <List<Products>>) {
               if (response.isSuccessful){
                   var product= response.body()
                   product?.let {
                        productlist.addAll(it)
                       productadapter.notifyDataSetChanged()
                   }
               }
           }

           override fun onFailure(call: Call<List<Products>>, t: Throwable) {
               Log.d("TAG", "onFailure: ")
           }

       })
    }


}


