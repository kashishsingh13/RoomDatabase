package com.example.practiceapplication.Network

import com.example.practiceapplication.ApiServiceProduct
import retrofit2.Retrofit
import retrofit2.converter.gson.GsonConverterFactory

class ApiProduct {
    companion object{
        private var retrofit:Retrofit?=null
        fun init(): ApiServiceProduct{
            if (retrofit==null){
                retrofit= Retrofit.Builder().baseUrl("https://api.escuelajs.co/api/v1/")
                    .addConverterFactory(GsonConverterFactory.create()).build()
            }
            return (retrofit!!.create(ApiServiceProduct::class.java))
        }
    }
}