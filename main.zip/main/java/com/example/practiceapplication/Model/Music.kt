package com.example.practiceapplication.Model

data class Music(
    var id : Int,
    var name:String,
    var picture:String,
    var picture_big:String,
    var radio:String,
    var type:String
)
