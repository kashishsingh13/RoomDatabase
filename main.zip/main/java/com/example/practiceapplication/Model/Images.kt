package com.example.practiceapplication.Model

data class Images(
    var image:String
)