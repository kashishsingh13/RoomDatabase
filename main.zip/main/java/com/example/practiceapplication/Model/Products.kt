package com.example.practiceapplication.Model

data class Products(
    var id:Int,
    var title:String,
    var price:Long,
    var description:String,
    var category:Category,
    var images:Images
)
