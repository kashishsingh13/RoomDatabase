package com.example.practiceapplication.Music_API

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.util.Log
import androidx.recyclerview.widget.LinearLayoutManager
import com.example.practiceapplication.Adapter.MusicAdapter
import com.example.practiceapplication.ApiService
import com.example.practiceapplication.Model.Music
import com.example.practiceapplication.Model.MusicResPonse
import com.example.practiceapplication.Model.MyData
import com.example.practiceapplication.Network.ApiClient
import com.example.practiceapplication.R
import com.example.practiceapplication.databinding.ActivityHome2Binding
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response
import retrofit2.Retrofit

class HomeActivity : AppCompatActivity() {
    private lateinit var binding:ActivityHome2Binding
    private lateinit var musicAdapter: MusicAdapter
    private var userlist= mutableListOf<MusicResPonse>()
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding= ActivityHome2Binding.inflate(layoutInflater)
        setContentView(binding.root)
        musicAdapter = MusicAdapter(this, userlist) // You can pass an empty list initially
        binding.recycle.adapter = musicAdapter
        binding.recycle.layoutManager = LinearLayoutManager(this)
        fetchUserList()
    }

    private fun fetchUserList() {
       ApiClient.init().getArtist("Akon").enqueue(object : Callback<MyData> {
            override fun onResponse(call: Call<MyData>, response: Response<MyData>) {
                // success

                if(response.isSuccessful){
                    val musicList = response.body()?.data
                    musicList?.let {
                        musicAdapter.musicList= it
                        musicAdapter.notifyDataSetChanged()

                    }



                }
            }

            override fun onFailure(call: Call<MyData>, t: Throwable) {
                Log.e("ApiClient", "Error fetching music list", t)

            }

        })

    }
}