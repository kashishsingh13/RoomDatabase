package com.example.practiceapplication

import android.telecom.Call
import com.example.practiceapplication.Model.Music
import com.example.practiceapplication.Model.MusicResPonse
import com.example.practiceapplication.Model.MyData
import retrofit2.http.GET
import retrofit2.http.Headers
import retrofit2.http.Path
import retrofit2.http.Query

interface ApiService {
    @Headers(
        "X-RapidAPI-Key:2786d296b1mshf7c988d6aa84924p134c97jsnc4cb1c88c87d",
        "X-RapidAPI-Host:deezerdevs-deezer.p.rapidapi.com"
    )
    @GET("search")
    fun getArtist(@Query("q") singer:String):retrofit2.Call<MyData>


}