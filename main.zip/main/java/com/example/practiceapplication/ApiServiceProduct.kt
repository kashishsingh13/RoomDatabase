package com.example.practiceapplication

import com.example.practiceapplication.Model.CreateProductRequest
import com.example.practiceapplication.Model.MyProduct
import com.example.practiceapplication.Model.Products
import retrofit2.Call
import retrofit2.http.Body
import retrofit2.http.GET
import retrofit2.http.POST
import retrofit2.http.Query

interface ApiServiceProduct {
    @GET("products")
    fun getproduct():Call<List<Products>>

    @POST("products")
    fun createProduct(@Body createProductRequest: CreateProductRequest): Call<Products>

}