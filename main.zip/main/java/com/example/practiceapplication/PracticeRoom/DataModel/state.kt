package com.example.practiceapplication.PracticeRoom.DataModel

data class state(
    var state_name:String
) {
    override fun toString(): String {
        return state_name
    }
}
