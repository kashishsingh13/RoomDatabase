package com.example.practiceapplication.PracticeRoom.DataModel

import androidx.room.Entity
import androidx.room.PrimaryKey


@Entity("User_data")
data class UserData(
    @PrimaryKey(autoGenerate = true)
    var id:Int=0,
    var name:String,
    var gender:String,
    var state:String
)
