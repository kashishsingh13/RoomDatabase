package com.example.practiceapplication.PracticeRoom.roomdatabase

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import com.example.practiceapplication.PracticeRoom.Dao.UDao
import com.example.practiceapplication.PracticeRoom.DataModel.UserData

@Database(entities = [UserData::class], version = 1)
abstract class UserDatabase :RoomDatabase() {
    abstract fun userdao() : UDao
    companion object{
        private var INSTENCE:UserDatabase?=null
        fun getInstance(context: Context):UserDatabase?{
            if (INSTENCE==null){
                synchronized(this){
                    INSTENCE = Room.databaseBuilder(context, UserDatabase::class.java,"item.db").allowMainThreadQueries().build()
                }
            }
            return INSTENCE
        }
    }
}

