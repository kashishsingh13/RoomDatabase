package com.example.practiceapplication.PracticeRoom

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.ArrayAdapter
import android.widget.Toast
import com.example.practiceapplication.PracticeRoom.DataModel.Gender
import com.example.practiceapplication.PracticeRoom.DataModel.UserData
import com.example.practiceapplication.PracticeRoom.DataModel.state
import com.example.practiceapplication.PracticeRoom.roomdatabase.UserDatabase
import com.example.practiceapplication.databinding.ActivityAddDataBinding
import kotlin.concurrent.thread

class AddDataActivity : AppCompatActivity() {
    private lateinit var binding:ActivityAddDataBinding
    private var stateList= mutableListOf<state>()
    private var user: UserData?=null
     var db:UserDatabase?=null
    private var genderList= mutableListOf<Gender>()
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding= ActivityAddDataBinding.inflate(layoutInflater)
        setContentView(binding.root)
        db= UserDatabase.getInstance(this)

        peparestate()
        val stateAdapter = ArrayAdapter(
            applicationContext,
            android.R.layout.simple_spinner_dropdown_item,
            stateList
        )

        binding.state.adapter = stateAdapter
        preparegender()
        val genderAdapter = ArrayAdapter(
            applicationContext,
            android.R.layout.simple_spinner_dropdown_item,
           genderList
        )

        binding.gender.adapter = genderAdapter

        binding.add.setOnClickListener {
            var name = binding.name.text.toString().trim()
            val selectedState = binding.state.selectedItem as state
            val selectedGender = binding.gender.selectedItem as Gender

            updaterecord(name,selectedState.state_name,selectedGender.gender)
        }

    }

    private fun updaterecord(name: String, selectedState: String, selectedGender: String) {
              var message=""
        thread(start = true){
            var userobject=UserData(name=name , state = selectedState, gender = selectedGender, id= if (user!=null) user!!.id else 0)

            db?.userdao()?.insetuser(userobject)
            message = "Record added successfully"

            runOnUiThread{
                Toast.makeText(this,message,Toast.LENGTH_SHORT).show()
                onBackPressedDispatcher.onBackPressed()
            }
        }
    }


    private fun peparestate(){
        stateList.add(state("Gujarat"))
        stateList.add(state("UP"))
        stateList.add(state("MP"))
        stateList.add(state("South"))

    }
    private fun preparegender(){
        genderList.add(Gender("MALE"))
        genderList.add(Gender("FEMALE"))
    }


}