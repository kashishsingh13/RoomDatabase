package com.example.practiceapplication.PracticeRoom

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import com.example.practiceapplication.R
import com.example.practiceapplication.databinding.ActivityRoomBinding

class RoomActivity : AppCompatActivity() {
    private lateinit var binding:ActivityRoomBinding
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding= ActivityRoomBinding.inflate(layoutInflater)
        setContentView(binding.root)

        binding.flotbutton.setOnClickListener {
            var intent= Intent(this,AddDataActivity::class.java)
            startActivity(intent)
        }
    }
}