package com.example.practiceapplication.PracticeRoom.Dao

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.Query
import com.example.practiceapplication.PracticeRoom.DataModel.UserData


@Dao
interface UDao {
    @Insert
    fun insetuser(user:UserData)
//
//    @Query("select * from User_data")
//    fun getalluser():MutableList<UserData>


}