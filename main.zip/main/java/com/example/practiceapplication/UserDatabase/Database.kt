package com.example.practiceapplication.UserDatabase

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import com.example.practiceapplication.Dao.UserDao
import com.example.practiceapplication.Model.Item


@Database(entities = [Item::class], version = 1)
 abstract class Database :RoomDatabase() {
     abstract fun userDao(): UserDao
     companion object{
         private var INSTENCE:com.example.practiceapplication.UserDatabase.Database?=null
         fun getInstence(context: Context):com.example.practiceapplication.UserDatabase.Database?{
             if (INSTENCE==null){
                 synchronized(this){
                     INSTENCE= Room.databaseBuilder(context, com.example.practiceapplication.UserDatabase.Database::class.java,"user.db").allowMainThreadQueries().build()
                 }
             }
             return INSTENCE

         }


     }
}